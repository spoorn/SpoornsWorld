you found me ♡
important stuff:

author/owner: glazebee
https://www.planetminecraft.com/member/glazebee/      
link to the owner's discord server: https://discord.gg/umWervYtQN

if you have any issues with anything join the discord server and contact the owner via the server or DM's.

♡ you can stream/record with the pack in use and upload content to social media platforms, just credit the owner when 
  asked about the rescource pack. :)
♡ don't use any content from the pack for your own personal resource pack unless discussed and agreed on by the owner.
♡ do not reupload this pack under any circumstances.
♡ just don't steal my content or you're smelly!

ince you are here i just wanted to thank you for using my resource pack. i love making them and a lot of effort goes
into them. if you would like to support me then my personal paypal is on my planet minecraft page at 
https://www.planetminecraft.com/member/glazebee/      

happy mining <33